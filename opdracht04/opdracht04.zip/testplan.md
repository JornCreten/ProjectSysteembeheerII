# Testplan taak 4: MDT

1. Voer de stappen uit de [documentatie](https://github.com/HoGentTIN/p2ops-1920-a03/blob/master/opdracht04/Documentatie.md) uit en reproduceer deze opstelling
2. installeer de client, download is beschikbaar [hier](https://github.com/HoGentTIN/p2ops-1920-a03/blob/master/opdracht04/Testvm.ova). Importeer deze VM in je virtualbox.

### Windows 10:
1. Selecteer Windows 10 bij het selectiescherm van MDT op de client
2. Indien je ingelogd bent in de windows client:
  - Controleer in het control panel of de te installeren applicaties geïnstalleerd zijn
### Server 2016
1. Selecteer Server 2016 bij het selectiescherm van MDT op de client
2. Indien je ingelogd bent na deze procedure:
  - Controleer in server manager of je de nodige roles hebt
  - Controleer of SQL geïnstalleerd is in het control panel
#### Auteur(s) testplan: Jorn Creten
