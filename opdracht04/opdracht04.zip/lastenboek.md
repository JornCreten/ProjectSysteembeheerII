# Lastenboek Taak 1: Microsoft Deployment Toolkit


## Deliverables

* Technische documentatie?
    - Hoe kan een teamlid de opstelling reproduceren?
    - Commando's en opties voor installatie
* Stappenplan WSUS
* Testplan en testrapport

## Deeltaken

1. Windows 2016 Server Script Schrijven
    - Verantwoordelijke: Dario Van Heck
    - Tester: Jorn Creten
2. Windows 10 Client Script Schrijven
    - Verantwoordelijke: Dario Van Heck
    - Tester: Jorn Creten
3. Windows 10 Installeren
    - Verantwoordelijke: Jorn Creten, Dario Van Heck
    - Tester: Dario Van Heck
4. Windows Server 2016 Installeren
    - Verantwoordelijke: Jorn Creten
    - Tester: Dario Van Heck
5. WSUS-Server
    - Verantwoordelijke: Jorn Creten
    - Tester: Dario Van Heck
6. Documentatie Schrijven
    - Verantwoordelijke: Jorn Creten
    - Tester: Dario Van Heck (opstelling reproduceren en opmaak documentatie optimiseren)
7. Demo Windows
    - Verantwoordelijke: Jorn Creten

## Tijdbesteding

| Student    | Geschat | Gerealiseerd |
| :---       | ---:    | ---:         |
| Jorn Creten  |  48       |   43,35           |
| Dario Van Heck   |     42    |    65,26          |
| **totaal** |    90     |        108,61      |

