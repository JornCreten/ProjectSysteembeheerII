# Testrapport taak 4: MDT Test

## Test 1

**Uitvoerder(s) test:** Dario Van Heck\
**Uitgevoerd op:** 26/042020\
**Github commit:**  COMMIT HASH 

Na het reproduceren van de opstelling en het installeren van de client:
 * **Windows 10:**
    - De applicaties die moesten geïnstalleerd worden staan in het control panel
 * **Server 2016:**
    - De nodige roles zijn geïnstalleerd
    - SQL Server is geïnstalleerd
