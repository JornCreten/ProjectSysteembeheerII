### WSUS TEST
* installeer Windows Server Update Services op de server onder roles (helemaal onderaan)
* Maak een folder genaamd "WSUS" aan in de C Drive
* als remote path bij de installatie van WSUS geef "C:\WSUS" in
* Druk op next tot de installatie gedaan is, klik dan op "Launch post-installation tasks", en wacht tot dit gedaan is
* Open Windows Server update services onder tools, en run de configuratie
* Selecteer Engels & Nederlands
* Selecteer de nodige versies van windows; Windows 10 en Server 2016, evt Edge 
* Selecteer alles bij classifications
* Zet de synchronizatie op een handig moment (bijvoorbeeld 's nachts), next
* Begin de initiele configuratie
* klik op finish